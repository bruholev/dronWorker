package kg.hunter.v3.hunter.v13;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class RecordInputValues {

    @Id
    @GeneratedValue
    private int Id;

    @Column
    private String inputValues;


    public RecordInputValues( String inputValues) {

        this.inputValues = inputValues;
    }

    public RecordInputValues() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getInputValues() {
        return inputValues;
    }

    public void setInputValues(String inputValues) {
        this.inputValues = inputValues;
    }
}
