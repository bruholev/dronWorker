package kg.hunter.v3.hunter.v13;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;


@Controller
public class SearchController {
    @Autowired
    private SearchService searchService;


    //  отправляем запрос
    @GetMapping("/upload")
    public String getRecords(Model model){
    List list=searchService.allinputjpa();
        model.addAttribute("records",list);
         return "result2";}

    @GetMapping("/uploadoutput")
    public String getOutputRecords(Model model){
            List list = searchService.allOutputjpa();
            model.addAttribute("records", list);
            return "result";

    }

    // получаем список результатов поиска
    @RequestMapping("/insert/{inputValues}")
    public String setProduct(@PathVariable("inputValues") String inputValues){
       searchService.searchGoods(inputValues);
        return "allComplete";
    }

    @RequestMapping("/word/{name}")
    public String setWord(@PathVariable("name") String name){

        return searchService.recordInsert(name);
    }

// выводим список на экран
}