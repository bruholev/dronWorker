package kg.hunter.v3.hunter.v13;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class RecordOutputValues {

@Id
@GeneratedValue
private int id;
@Column
private String outputValues;
@Column
private String reference;
@Column
private int cost;

    public void setReference(String reference) {
        this.reference = reference;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public RecordOutputValues(String outputValues, String  reference, int cost) {
        this.outputValues = outputValues;
        this.reference=reference;
        this.cost=cost;
    }

    public String getReference() {
        return reference;
    }

    public RecordOutputValues() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOutputValues() {
        return outputValues;
    }

    public void setOutputValues(String outputValues) {
        this.outputValues = outputValues;
    }
}
