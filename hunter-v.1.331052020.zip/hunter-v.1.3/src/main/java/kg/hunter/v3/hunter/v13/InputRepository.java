package kg.hunter.v3.hunter.v13;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface InputRepository  extends JpaRepository<RecordInputValues,Integer>  {
}

