package kg.hunter.v3.hunter.v13;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
@Service
public class SearchService {

    @Autowired
    InputRepository inputRepository;

    @Autowired
    OutputRepository outputRepository;
    private static final String SOM = " сом";
    private static final String RUB = " р.";
     public List<RecordInputValues> allinputjpa() {
        return inputRepository.findAll();
    }
    public List<RecordOutputValues> allOutputjpa(){
         return  outputRepository.findAll(Sort.by(Sort.Direction.ASC, "cost"));
    }
    public void recordOutput(String outputValues,String reference,int cost){
        RecordOutputValues recordOutputValues=new RecordOutputValues(outputValues,reference,cost);
        outputRepository.save(recordOutputValues);
    }
    public void recordOutputSort(){
         outputRepository.findAll();
    }
    public String recordInsert(String inputValues) {
        RecordInputValues recordInputValues = new RecordInputValues(inputValues);
        inputRepository.save(recordInputValues);
        return "Поиск  " + inputValues + " начался";
    }

    public String searchGoods(String goods) {
        inputRepository.deleteAll();
        outputRepository.deleteAll();
        ConectJsoup conectJsoup=new ConectJsoup();
        ChangeCharset changeCharset=new ChangeCharset();
        String uri,url, attr1, attr2,txt,sequnce=" ";
        Document doc = null;
        Elements links;
        int count=0,cost;
        RecordInputValues recordInputValues;
        url = "https://www.google.com/search?q=" + goods
                + "&rlz=1C1YUOF_ruKG843KG843&oq=vzx&aqs=chrome.2.69i57j0l3j69i60l2.3512j0j7&sourceid=" +
                "chrome&ie=UTF-8&num=" + 100;

        try {
            doc=conectJsoup.parseDoc(url);
            links = doc.select("a[href]");  //разбираем ссылки
       for (Element link : links) {
            attr1 = link.attr("href");
            attr2 = link.attr("class");
       if (!attr2.startsWith("_Zkb") && attr1.startsWith("/url?q=")) {
            attr1=changeCharset.changeCharsetSequence(attr1);
           if(attr1.length()<254){
               attr1 = attr1.substring(1, attr1.indexOf("&sa"));
               recordInsert(attr1);
           count++;
           }
            }}
        } catch (NullPointerException e) { e.printStackTrace();}//ссылки длинные получились поэтому доменное имя только
        System.out.println(count);
        for(int i=1;i<count;i++){
            try {
            recordInputValues=inputRepository.findById(i).orElse(new RecordInputValues());
            uri=recordInputValues.getInputValues();
                System.out.println(uri+"|uri");
                if(uri!=null){
            uri=changeCharset.changeCharsetSequence(uri);
            doc=conectJsoup.parseDoc(uri);
                System.out.println("doc");
                if(doc.hasText()){
                txt=doc.text();
                System.out.println("text");
                    sequnce=conectJsoup.cuttingTxtGoods(txt);
                    System.out.println("sequence");
                 cost=conectJsoup.cuttingCostGoods(sequnce);
                 System.out.println("cost");
                 if(cost>0&&sequnce!=""){
                 recordOutput(sequnce,uri,cost);
                 System.out.println("recordOutput");}
             }}
            } catch(NullPointerException e){e.printStackTrace();}
            }
            return "List is complete";
            }

}