package kg.hunter.v3.hunter.v13;

public class ChangeCharset {

    public ChangeCharset() {
    }

    public String changeCharsetSequence(String attr1){
      try{  while (attr1.contains("%253A")||attr1.contains("%252F")||attr1.contains("%3F")
                ||attr1.contains("%3A") ||attr1.contains("%2F")||attr1.contains("/url%3Fq=")
                ||attr1.contains("/url?q=")||attr1.contains("%25252F")||attr1.contains("%25253A")
                ||attr1.contains("%2526")||attr1.contains("%26")) {

            attr1 = attr1.replace("%253F", "?");
            attr1 = attr1.replace("%3F", "?");
            attr1 = attr1.replace("%253D", "=");
            attr1 = attr1.replace("%3D", "=");
            attr1 = attr1.replace("%253A", ":");
            attr1 = attr1.replace("%25253A", ":");
            attr1 = attr1.replace("%3A", ":");
            attr1 = attr1.replace("%252F", "/");
            attr1 = attr1.replace("%25252F", "/");
            attr1 = attr1.replace("%2F", "/");
            attr1 = attr1.replace("/url?q=", " ");
            attr1 = attr1.replace("/url%3Fq=", " ");
            attr1 = attr1.replace("%2526", "&");
            attr1 = attr1.replace("%26", "& ");
        }}catch (NullPointerException e){e.printStackTrace();}
        return attr1;
    }
}
