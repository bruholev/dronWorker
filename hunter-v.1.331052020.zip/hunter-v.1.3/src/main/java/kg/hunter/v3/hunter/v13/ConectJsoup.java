package kg.hunter.v3.hunter.v13;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConectJsoup {
   private Document doc=null;
    private final String charset = "utf-8";
 private static final String words = " som | KGS | Сом | руб| сом ";
 private static final String digits="\\d+";
    public ConectJsoup() {
    }

    public Document parseDoc(String url) {
     try{
     
     doc= Jsoup.connect(url ).userAgent("Jsoup client").get();
      }
     catch (  MalformedURLException e ) {   e.printStackTrace();}
     catch(NullPointerException e){ e.printStackTrace();}
     catch ( IOException e){  e.printStackTrace();}
     
     return doc;
 }

 public int cuttingCostGoods(String seq){
  System.out.println("cuttingCostGoods");
 int cost=0,len;
 String word;
  Pattern patternSom=Pattern.compile(digits);


  System.out.println(seq);
  Matcher matcherSom=patternSom.matcher(seq);
  if (matcherSom.find())
  {System.out.println("matcher"+"|"+seq.length());
   word=seq.substring(matcherSom.start(),matcherSom.end());
   System.out.println(seq.substring(matcherSom.start(),matcherSom.end()));
    cost= Integer.parseInt(word);
   }
  return cost;
   }


 public String cuttingTxtGoods(String seq){
  System.out.println("cuttingTxtGoods");
  String word="",text="";
  Pattern patternSom=Pattern.compile(words);
  Matcher matcherSom=patternSom.matcher(seq);
  if (matcherSom.find())
  {System.out.println("matcherTxt");
   try{word=seq.substring(matcherSom.start()-8,matcherSom.end());
    word=word.replace(" ","");
   System.out.println(seq.substring(matcherSom.start()-8,matcherSom.end())+"|"+word.length());}
   catch(StringIndexOutOfBoundsException e){e.printStackTrace();}
  }
  return word;

 }
}
